Was soll das Programm machen:

Erste Berechnung:

1) Trennung der Daten
-> String soll an Komma getrennt werden und in Cols gespeichert werden

2) Nur "Compress" Daten auswaehlen
-> Entweder Drop Statement -> copy und dann drop
-> oder nicht beachten der Zeilen

3) Force Daten [microN] auswaehlen und nur die + Werte auswaehlen
die negativ Force Daten wegloeschen
->

\\ Zwischenstand -> Original Daten in einer Excel und neue Daten in neuem Reiter

4) Force Daten, die in microN sind in N ausrechnen, indem die Daten 10 hoch 6 geteilt werden => 
Force microN / 10 hoch 6 = force in N
->

5) Current Size in microm ist der Durchmesser und es muss daraus  der Redius berechnet werden. Deswegen
muss: "Current size microm = 2 / 10 hoch 6 " Radius in m
-> 

6) Flaeche aus Radius in m: A = $pi * r hoch 2

7) Delta (Spannung) berechnen: delta = F / A [N/m hoch 2]
8) E (Dehnung) => E = L0 - Ln / L0 (L0 erste Messung des Durchmessers)

