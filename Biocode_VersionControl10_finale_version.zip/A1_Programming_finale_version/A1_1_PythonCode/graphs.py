import matplotlib.pyplot as plt
import re


class Graphs:

    def __init__(self, filename, dataframe) -> None:
        self.filename = filename
        self.df_visualize = dataframe

        print(self.df_visualize.columns)

    def wildcard_for_columnname(self, columnname) -> str:
        pattern = re.compile(rf'{columnname}.*')
        matching_columns = [col for col in self.df_visualize.columns if pattern.match(col)]
        if matching_columns:
            return matching_columns[0]  # Return the first match instead of a list
        else:
            raise ValueError(f"No match found for column: {columnname}")

    def plotting(self):

        var_spannung_y_var = self.wildcard_for_columnname("Sigma")
        var_dehnung_x_var = self.wildcard_for_columnname("Epsilon")

        plt.title(f'Spannungs-Dehnungs-Diagramm') 
        
        plt.figure(figsize=(20, 20))

        plt.subplot()
        plt.plot(self.df_visualize[var_dehnung_x_var], self.df_visualize[var_spannung_y_var],label=f'Sigma / Epsilon')
        plt.ylabel(f'Sigma (Spannung)')
        plt.xlabel(f'Epsilon (Dehnung)')
        plt.grid()
        plt.show()

    def run(self):
        self.plotting()
