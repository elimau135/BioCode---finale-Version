import tkinter as tk
from tkinter import filedialog

from mainScript import MainScript


class Gui:
   
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Main Window")
        self.root.geometry("400x400")
        pass

    def selectFileInFolder(self):
        self.filename = filedialog.askopenfilename(
            title="Browse File"
        )
        self.instanceOfMainskript = MainScript(self.filename)
        self.instanceOfMainskript.run()


    def close(self):
        self.root.quit()

    def functionWithButton(self):
# Configure grid
        self.root.columnconfigure(0, weight=1)
        self.root.columnconfigure(1, weight=1)
        self.root.columnconfigure(2, weight=1)
        self.root.rowconfigure(0, weight=1)
        self.root.rowconfigure(1, weight=1)
        self.root.rowconfigure(2, weight=1)
        self.root.rowconfigure(3, weight=1)

        button = tk.Button(self.root, text='Browse for file!', command=self.selectFileInFolder, height=2, width=20)
        button.grid(column=1, row=1, pady=10)

        exitButton = tk.Button(self.root, text='Exit', command=self.close, height=2, width=20)
        exitButton.grid(column=1, row=2, pady=10)


    def run(self):
        self.functionWithButton()
        self.root.mainloop()


        # x,x,x,x,x
