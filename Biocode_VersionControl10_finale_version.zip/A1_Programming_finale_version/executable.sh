script_dir="$(dirname "$(readlink -f "$0")")"

echo "Running Python script..."

# Run the Python script located in the same directory as this Bash script
python3 "${script_dir}/A1_1_PythonCode/main.py"

echo "Python script execution completed."
