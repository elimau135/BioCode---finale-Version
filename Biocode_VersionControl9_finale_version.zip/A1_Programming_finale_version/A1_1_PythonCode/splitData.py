import pandas as pd
import math

class SplitColumn:

    def __init__(self, dataframe_to_split): 
        self.df = dataframe_to_split
        print(self.df.columns)

    def run(self):

        header_string = self.df.columns
        print(header_string)
        if isinstance(header_string, str):
            columns = header_string.split(",")
            self.dataframe_for_biocalc = pd.DataFrame(columns=columns) 
            return self.dataframe_for_biocalc()


