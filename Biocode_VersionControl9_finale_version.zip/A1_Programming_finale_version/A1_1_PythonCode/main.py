from gui import Gui


class Main:
    
    def __init__(self):
        self.gui_Instance = Gui()

    def run(self):
        self.gui_Instance.run()


instanceOfMain = Main()
instanceOfMain.run()     
