import matplotlib.pyplot as plt
import re


class Graphs:

    def __init__(self, filename, dataframe) -> None:
        self.filename = filename
        self.df_visualize = dataframe

        print(self.df_visualize.columns)

    def wildcard_for_columnname(self, columnname) -> str:
        pattern = re.compile(rf'{columnname}.*')
        matching_columns = [col for col in self.df_visualize.columns if pattern.match(col)]
        if matching_columns:
            return matching_columns[0]  # Return the first match instead of a list
        else:
            raise ValueError(f"No match found for column: {columnname}")

    def plotting(self):

            
           
        # Assuming self.wildcard_for_columnname is a method that returns the appropriate column name based on a pattern

        var_spannung_y_var = self.wildcard_for_columnname("Sigma")
        var_dehnung_x_var = self.wildcard_for_columnname("Epsilon")
        var_tip_displacement_x_var = self.wildcard_for_columnname("Tip_Displacement")

        # Create a figure with 2 subplots, smaller size
        fig, axs = plt.subplots(2, 1, figsize=(10, 10))

        # First subplot: Spannungs-Dehnungs-Diagramm
        axs[0].plot(self.df_visualize[var_dehnung_x_var], self.df_visualize[var_spannung_y_var], label='Sigma / Epsilon')
        axs[0].set_title('Spannungs-Dehnungs/Compression-Diagramm /')
        axs[0].set_ylabel('Sigma (Spannung/Compression)')
        axs[0].set_xlabel('Epsilon (Dehnung)')
        axs[0].grid()
        axs[0].legend()

        # Second subplot: Force-Tip_Displacement
        axs[1].plot(self.df_visualize[var_tip_displacement_x_var], self.df_visualize["Force (N)"], label='Force/ Tip Displacement')
        axs[1].set_title('Force-Tip_Displacement')
        axs[1].set_ylabel('Force (N)')
        axs[1].set_xlabel('Tip Displacement (m)')
        axs[1].grid()
        axs[1].legend()

        # Adjust layout to prevent overlap
        plt.tight_layout()

        # Show the plot
        plt.show()


    def run(self):
        self.plotting()
