
import pandas as pd  # Import the pandas library for data manipulation
import numpy as np  # Import the numpy library for numerical operations
import re  # Import the re library for regular expressions

from graphs import Graphs  # Import the Graphs class from the graphs module
from splitData import SplitColumn  # Import the SplitColumn class from the splitData module

import csv

class MainScript:

    def __init__(self, filename):  # Initialization method
        self.filename = filename  # Store the filename

    def createDataframe(self) -> pd.DataFrame:
        with open(self.filename, 'r', encoding='unicode_escape') as file:  # Open the file with the given filename
            first_line = file.readline()  # Read the first line to determine the delimiter
        
        # Determine the delimiter
        if ';' in first_line:  # Check if the delimiter is a semicolon
            delimiter = ';'  # Set the delimiter to semicolon
        elif ',' in first_line:  # Check if the delimiter is a comma
            delimiter = ','  # Set the delimiter to comma
        else:
            raise ValueError("Unknown delimiter in the CSV file.")  # Raise an error if the delimiter is unknown
        
        # Read the CSV file with the determined delimiter
        df = pd.read_csv(self.filename, sep=delimiter, encoding='unicode_escape')  # Read the CSV file into a DataFrame
        return df  # Return the DataFrame

    def wildcard_for_columnname(self, columnname) -> str:
        pattern = re.compile(rf'{columnname}.*')  # Compile a regular expression pattern for the column name
        matching_columns = [col for col in self.dataframe.columns if pattern.match(col)]  # Find matching columns
        if matching_columns:
            return matching_columns[0]  # Return the first matching column name
        else:
            raise ValueError(f"No match found for column: {columnname}")  # Raise an error if no match is found

    def delete_unnecessary_data(self):
        print("Before delete_unnecessary_data:")  # Print message before deleting data
        print(self.dataframe)  # Print the DataFrame

        def delete_not_compress_values():
            print(self.dataframe.columns)  # Print the DataFrame columns
            print(self.dataframe["Cycle"])  # Print the "Cycle" column
            self.dataframe = self.dataframe[self.dataframe["Cycle"] == "1-Compress"]  # Keep only rows where "Cycle" is "1-Compress"

        def delete_negative_force_values():
            force_val = self.wildcard_for_columnname("Force")  # Get the force column name
            self.dataframe[force_val] = pd.to_numeric(self.dataframe[force_val], errors='coerce')  # Convert force values to numeric
            # Keep the first row even if its force value is negative or NaN
            self.dataframe = self.dataframe[(self.dataframe.index == 0) | (self.dataframe[force_val] >= 0) | self.dataframe[force_val].isna()]  # Filter rows

        delete_not_compress_values()  # Delete non-compress values
        delete_negative_force_values()  # Delete negative force values

        print("After delete_unnecessary_data:")  # Print message after deleting data
        print(self.dataframe)  # Print the DataFrame
        self.dataframe = self.dataframe.reset_index(drop=True)  # Reset the DataFrame index

    def umwandlung_der_micro_newton_values(self):
        print("Before umwandlung_der_micro_newton_values:")  # Print message before conversion
        print(self.dataframe)  # Print the DataFrame

        var_force_col = self.wildcard_for_columnname("Force")  # Get the force column name
        var_current_size_col = self.wildcard_for_columnname("Current Size")  # Get the current size column name
        var_tip_displacement_col = self.wildcard_for_columnname("Tip Displacement")  # Get the tip displacement column name

        def umwandlung_force():
            self.dataframe["Force (N)"] = self.dataframe[var_force_col] / np.power(10, 6)  # Convert force values to Newtons

        def umwandlung_current_size():
            self.dataframe[var_current_size_col] = pd.to_numeric(self.dataframe[var_current_size_col], errors='coerce')  # Convert current size values to numeric
            self.dataframe["Current_Size (m)"] = self.dataframe[var_current_size_col] / np.power(10, 6)  # Convert current size to meters
            self.dataframe["Radius (m)"] = (self.dataframe[var_current_size_col] / 2) / np.power(10, 6)  # Calculate radius in meters

        def umwandlung_tip_displacement():
            self.dataframe[var_tip_displacement_col] = pd.to_numeric(self.dataframe[var_tip_displacement_col], errors='coerce')  # Convert tip displacement values to numeric
            self.dataframe["Tip_Displacement_in_m (um / 10^6)"] = self.dataframe[var_tip_displacement_col] / np.power(10, 6)  # Convert tip displacement to meters

        umwandlung_force()  # Perform force conversion
        umwandlung_current_size()  # Perform current size conversion
        umwandlung_tip_displacement()  # Perform tip displacement conversion

        print("After umwandlung_der_micro_newton_values:")  # Print message after conversion
        print(self.dataframe)  # Print the DataFrame

    def mathematical_operations(self):
        print("Before mathematical_operations:")  # Print message before mathematical operations
        print(self.dataframe)  # Print the DataFrame

        def function_calc_theta_winkel():
            var_tip_displacement_col = self.wildcard_for_columnname("Tip_Displacement")  # Get the tip displacement column name
            var_radius_col = self.wildcard_for_columnname("Radius")  # Get the radius column name
            argument_for_arccos = (self.dataframe[var_radius_col] - self.dataframe[var_tip_displacement_col]) / self.dataframe[var_radius_col]  # Calculate argument for arccos
            self.dataframe["Theta"] = np.arccos(argument_for_arccos)  # Calculate theta using arccos
            print("Argument for arccos:", argument_for_arccos)  # Print argument for arccos
            print("Theta:", np.degrees(self.dataframe["Theta"]))  # Print theta in degrees

        def function_calc_alpha():
            var_tip_displacement_col = self.wildcard_for_columnname("Tip Displacement")  # Get the tip displacement column name
            var_radius_col = self.wildcard_for_columnname("Radius")  # Get the radius column name
            var_theta = self.wildcard_for_columnname("Theta")  # Get the theta column name
            self.dataframe["Alpha"] = (self.dataframe[var_radius_col] - self.dataframe[var_tip_displacement_col]) * np.tan(self.dataframe[var_theta])  # Calculate alpha
            print(self.dataframe["Alpha"])  # Print alpha

        def calc_two_parts():
            def function_calc_left_part():
                var_radius_col = self.wildcard_for_columnname("Radius")  # Get the radius column name
                var_alpha_col = self.wildcard_for_columnname("Alpha")  # Get the alpha column name
                var_upper_part = 2 * (1 + 0.5) * np.power(self.dataframe[var_radius_col], 2)  # Calculate the upper part of the left part
                var_lower_part = np.power(np.power(self.dataframe[var_alpha_col], 2) + 4 * np.power(self.dataframe[var_radius_col], 2), 1.5)  # Calculate the lower part of the left part
                return var_upper_part / var_lower_part  # Return the left part

            def function_calc_right_part():
                var_radius_col = self.wildcard_for_columnname("Radius")  # Get the radius column name
                var_alpha_col = self.wildcard_for_columnname("Alpha")  # Get the alpha column name
                v = 0.5  # Define the Poisson's ratio
                var_upper_part = 1 - np.power(v, 2)  # Calculate the upper part of the right part
                var_lower_part = np.power(np.power(self.dataframe[var_alpha_col], 2) + 4 * np.power(self.dataframe[var_radius_col], 2), 0.5)  # Calculate the lower part of the right part
                return var_upper_part / var_lower_part  # Return the right part

            left_part_for_calc = function_calc_left_part()  # Calculate the left part
            right_part_for_calc = function_calc_right_part()  # Calculate the right part
            self.dataframe["function_f_a"] = left_part_for_calc + right_part_for_calc  # Calculate the function f_a
            print(self.dataframe["function_f_a"])  # Print the function f_a

        def function_for_e_calc():
            def function_calc_left_part():
                var_radius_col = self.wildcard_for_columnname("Radius")  # Get the radius column name
                var_alpha_col = self.wildcard_for_columnname("Alpha")  # Get the alpha column name
                var_force_col = self.wildcard_for_columnname("Force")  # Get the force column name
                var_tip_displacement_col = self.wildcard_for_columnname("Tip Displacement")  # Get the tip displacement column name
                v = 0.5  # Define the Poisson's ratio
                var_upper_part = 3 * (1 - np.power(v, 2)) * self.dataframe[var_force_col]  # Calculate the upper part of the left part
                var_lower_part = 4 * self.dataframe[var_tip_displacement_col] * self.dataframe[var_alpha_col]  # Calculate the lower part of the left part
                return var_upper_part / var_lower_part  # Return the left part

            def function_calc_right_part():
                var_radius_col = self.wildcard_for_columnname("Radius")  # Get the radius column name
                var_alpha_col = self.wildcard_for_columnname("Alpha")  # Get the alpha column name
                var_force_col = self.wildcard_for_columnname("Force")  # Get the force column name
                var_tip_displacement_col = self.wildcard_for_columnname("Tip Displacement")  # Get the tip displacement column name
                var_f_a_col = self.wildcard_for_columnname("function_f_a")  # Get the function f_a column name
                var_upper_part = self.dataframe[var_f_a_col] * self.dataframe[var_force_col]  # Calculate the upper part of the right part
                var_lower_part = np.pi * self.dataframe[var_tip_displacement_col]  # Calculate the lower part of the right part
                return var_upper_part / var_lower_part  # Return the right part

            left_part_for_calc = function_calc_left_part()  # Calculate the left part
            right_part_for_calc = function_calc_right_part()  # Calculate the right part
            self.dataframe["E Modul"] = left_part_for_calc - right_part_for_calc  # Calculate the E modulus
            print(self.dataframe["E Modul"])  # Print the E modulus

        function_calc_theta_winkel()  # Calculate theta
        function_calc_alpha()  # Calculate alpha
        calc_two_parts()  # Calculate the two parts
        function_for_e_calc()  # Calculate the E modulus

        print("After mathematical_operations:")  # Print message after mathematical operations
        print(self.dataframe)  # Print the DataFrame

    def e_modul_spannung_dehnung(self):
        print("Before e_modul_spannung_dehnung:")  # Print message before E modulus, stress, and strain calculations
        print(self.dataframe)  # Print the DataFrame

        def calc_area():
            var_radius = self.wildcard_for_columnname("Radius")  # Get the radius column name
            self.dataframe["Flaeche (m)"] = np.pi * np.power(self.dataframe[var_radius], 2)  # Calculate the area

        def calc_delta():
            var_area = self.wildcard_for_columnname("Flaeche")  # Get the area column name
            self.dataframe["Sigma (Spannung) [N /m hoch 2]"] = self.dataframe["Force (N)"] / self.dataframe[var_area]  # Calculate the stress

        def calc_E():
            var_current_size = self.wildcard_for_columnname("Current_Size")  # Get the current size column name
            print(self.dataframe)  # Print the DataFrame
            print(self.dataframe[var_current_size])  # Print the current size column
            self.dataframe["Epsilon (Dehnung)"] = ((self.dataframe.at[0, var_current_size] - self.dataframe[var_current_size]) / self.dataframe.at[0, var_current_size]) * 100  # Calculate the strain

        def calc_e_modul():
            var_delta_col = self.wildcard_for_columnname("Sigma")  # Get the stress column name
            var_e_col = self.wildcard_for_columnname("Epsilon")  # Get the strain column name
            self.dataframe[var_delta_col] = pd.to_numeric(self.dataframe[var_delta_col], errors='coerce')  # Convert stress values to numeric
            self.dataframe[var_e_col] = pd.to_numeric(self.dataframe[var_e_col], errors='coerce')  # Convert strain values to numeric
            self.dataframe["E_Modul (Spannung / Dehnung)"] = self.dataframe[var_delta_col] / self.dataframe[var_e_col]  # Calculate the E modulus

        calc_area()  # Calculate the area
        calc_delta()  # Calculate the stress
        calc_E()  # Calculate the strain
        calc_e_modul()  # Calculate the E modulus

        print("After e_modul_spannung_dehnung:")  # Print message after E modulus, stress, and strain calculations
        print(self.dataframe)  # Print the DataFrame

    def run(self):
        self.original_dataframe = self.createDataframe()  # Create the original DataFrame
        self.dataframe = self.original_dataframe.copy()  # Make a copy of the original DataFrame

        # self.split_data_instance = SplitColumn(self.original_dataframe)  # Initialize SplitColumn class with the original DataFrame
        # self.dataframe_for_biocalc = self.split_data_instance.run()  # Run the SplitColumn instance

        self.var_len_of_dataframe = len(self.dataframe)  # Get the length of the DataFrame

        self.delete_unnecessary_data()  # Delete unnecessary data
        self.umwandlung_der_micro_newton_values()  # Convert micro newton values
        
        self.mathematical_operations()  # Perform mathematical operations
        self.e_modul_spannung_dehnung()  # Calculate E modulus, stress, and strain
       
        self.dataframe.to_csv(self.filename, index=False)  # Save the processed DataFrame to CSV
        new_filename = self.filename + '_original_data.csv'
        print(self.filename)
        self.original_dataframe.to_csv(new_filename, index=False)

        self.graphs_instance = Graphs(self.filename, self.dataframe)  # Initialize Graphs class with filename and DataFrame
        self.graphs_instance.run()  # Run the Graphs instance to generate graphs

